let VEHICLES = [];
let PRODUCTS = [];
let CART = [];

async function loadCSVs() {
  const vehRes = await fetch('./data/vehicles.csv');
  const prodRes = await fetch('./data/products.csv');
  const vehText = await vehRes.text();
  const prodText = await prodRes.text();
  VEHICLES = parseCSV(vehText);
  PRODUCTS = parseCSV(prodText);
  buildYearMakeModelTrim();
  renderResults();
}

function uniq(arr){ return [...new Set(arr)]; }

function buildYearMakeModelTrim() {
  const yearSel = document.getElementById('year');
  const makeSel = document.getElementById('make');
  const modelSel = document.getElementById('model');
  const trimSel = document.getElementById('trim');

  yearSel.innerHTML = '<option value=\"\">Year</option>';
  makeSel.innerHTML = '<option value=\"\">Make</option>';
  modelSel.innerHTML = '<option value=\"\">Model</option>';
  trimSel.innerHTML = '<option value=\"\">Trim</option>';

  const years = uniq(VEHICLES.map(v => v.year)).sort((a,b)=>Number(b)-Number(a));
  years.forEach(y => yearSel.innerHTML += `<option value=\"${y}\">${y}</option>`);

  function updateMakes(){
    const y = yearSel.value;
    const makes = uniq(VEHICLES.filter(v => !y || v.year===y).map(v=>v.make)).sort();
    makeSel.innerHTML = '<option value=\"\">Make</option>' + makes.map(m=>`<option value=\"${m}\">${m}</option>`).join('');
    updateModels();
  }
  function updateModels(){
    const y = yearSel.value, m = makeSel.value;
    const models = uniq(VEHICLES.filter(v => (!y || v.year===y) && (!m || v.make===m)).map(v=>v.model)).sort();
    modelSel.innerHTML = '<option value=\"\">Model</option>' + models.map(x=>`<option value=\"${x}\">${x}</option>`).join('');
    updateTrims();
  }
  function updateTrims(){
    const y = yearSel.value, m = makeSel.value, mo = modelSel.value;
    const trims = uniq(VEHICLES.filter(v => (!y || v.year===y) && (!m || v.make===m) && (!mo || v.model===mo)).map(v=>v.trim)).sort();
    trimSel.innerHTML = '<option value=\"\">Trim</option>' + trims.map(t=>`<option value=\"${t}\">${t}</option>`).join('');
    renderResults();
  }

  yearSel.onchange = updateMakes;
  makeSel.onchange = updateModels;
  modelSel.onchange = updateTrims;
  trimSel.onchange = renderResults;
  updateMakes();
}

function matchesFitment(prod, y, make, model, trim) {
  // products.csv fitment format: "year:2018-2022;make:Honda;model:Civic;trim:EX|LX"
  // Empty selection means ignore that dimension
  const rules = (prod.fitment || '').split(';').map(s=>s.trim());
  const map = {};
  for (const r of rules) {
    const [k,v] = r.split(':');
    if (!k || !v) continue;
    map[k] = v;
  }
  if (y && map.year) {
    // year range or single value
    if (map.year.includes('-')) {
      const [a,b] = map.year.split('-').map(n=>Number(n));
      if (Number(y) < a || Number(y) > b) return false;
    } else {
      if (String(y) !== String(map.year)) return false;
    }
  }
  if (make && map.make && map.make !== make) return false;
  if (model && map.model && map.model !== model) return false;
  if (trim && map.trim) {
    const trims = map.trim.split('|').map(s=>s.trim());
    if (!trims.includes(trim)) return false;
  }
  return true;
}

function renderResults() {
  const y = document.getElementById('year').value;
  const make = document.getElementById('make').value;
  const model = document.getElementById('model').value;
  const trim = document.getElementById('trim').value;
  const grid = document.getElementById('results');
  grid.innerHTML = '';
  const filtered = PRODUCTS.filter(p => matchesFitment(p, y, make, model, trim));
  for (const p of filtered) {
    const card = document.createElement('div');
    card.className = 'border border-neutral-800 rounded-2xl overflow-hidden bg-neutral-900';
    card.innerHTML = `
      <div class="aspect-video bg-neutral-800 flex items-center justify-center">
        ${p.image_url ? `<img src="${p.image_url}" alt="${p.title}" class="w-full h-full object-cover">` : `<span class="text-neutral-500 text-sm">No image</span>`}
      </div>
      <div class="p-4 space-y-2">
        <div class="text-sm text-neutral-400">${p.brand || ''}</div>
        <div class="font-semibold">${p.title}</div>
        <div class="text-sm text-neutral-400">${p.category || ''}</div>
        <div class="flex items-center justify-between">
          <div class="text-lg font-semibold">$${Number(p.price).toFixed(2)}</div>
          <button data-sku="${p.sku}" class="btnAdd px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-neutral-700 text-sm">Add</button>
        </div>
        <div class="text-xs text-neutral-500">Vendor: ${p.supplier_name || ''} • Vendor SKU: ${p.vendor_sku || ''}</div>
      </div>
    `;
    grid.appendChild(card);
  }
  grid.querySelectorAll('.btnAdd').forEach(btn => btn.onclick = () => addToCart(btn.dataset.sku));
  updateCartUI();
}

function addToCart(sku) {
  const item = PRODUCTS.find(p => p.sku === sku);
  if (!item) return;
  const existing = CART.find(i => i.sku === sku);
  if (existing) existing.qty += 1;
  else CART.push({ sku: item.sku, title: item.title, price: Number(item.price), supplier_name: item.supplier_name, supplier_price: Number(item.supplier_price), vendor_sku: item.vendor_sku, qty: 1 });
  updateCartUI();
}

function updateCartUI() {
  const subtotal = CART.reduce((a,c)=> a + c.price * c.qty, 0);
  document.getElementById('subtotal').textContent = subtotal.toFixed(2);
  document.getElementById('cartStatus').textContent = `Cart: ${CART.reduce((a,c)=>a+c.qty,0)} items`;
}

function exportPOCSV() {
  // Group by supplier_name for basic dropship POs
  const groups = {};
  for (const c of CART) {
    const key = c.supplier_name || 'Unknown Supplier';
    groups[key] = groups[key] || [];
    groups[key].push(c);
  }
  // Create one CSV per supplier; for simplicity, one combined CSV
  const headers = ['supplier_name','vendor_sku','title','qty','unit_price','total'];
  let csv = headers.join(',') + '\n';
  for (const [supplier, items] of Object.entries(groups)) {
    for (const it of items) {
      const total = (it.supplier_price || it.price) * it.qty;
      csv += [escapeCSV(supplier), escapeCSV(it.vendor_sku||''), escapeCSV(it.title), it.qty, (it.supplier_price||it.price).toFixed(2), total.toFixed(2)].join(',') + '\n';
    }
  }
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'purchase_orders.csv';
  a.click();
  URL.revokeObjectURL(url);
}

function escapeCSV(val) {
  const s = String(val ?? '');
  if (s.includes(',') || s.includes('\"') || s.includes('\n')) {
    return '\"' + s.replaceAll('\"','\"\"') + '\"';
  }
  return s;
}

document.getElementById('btnLoad').onclick = loadCSVs;
document.getElementById('btnExportPO').onclick = exportPOCSV;
